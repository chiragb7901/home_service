""" import all the models in the folder here"""
from app.main.models.WorkerModel import Worker
from app.main.models.UserModel import User